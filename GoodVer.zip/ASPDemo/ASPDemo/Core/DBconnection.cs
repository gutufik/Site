﻿using System;
using MySql.Data;
using MySql.Data.MySqlClient;

namespace ASPDemo.Core
{
    public class DBconnection
    {
        private static string connStr = "server=10.0.4.152;user=a;database=OurSite;port=3306;password=a";
        public static MySqlConnection conn = new MySqlConnection(connStr);
    }
}
