﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASPDemo.Core;

namespace ASPDemo.Controllers
{
    public class ProjectController : Controller
    {
        ProjectStorage projects;

        public ProjectController(IProjectStorage _projects)
        {
            projects = _projects as ProjectStorage;
        }

        public IActionResult Index()
        {
            return View(projects.Projects);
        }
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Project project)
        {
            projects.Add(project);
            return RedirectToAction("Index");
        }
        public IActionResult Remove(int id)
        {
            projects.RemoveById(id);
            return RedirectToAction("Index");
        }
    }
}
