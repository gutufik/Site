﻿using System;
using System.Collections.Generic;
using System.Linq;
using MySql.Data.MySqlClient;

namespace OurSite.Core
{
    public static class ProjectStorage
    {
        public static List<Project> projects { get; set; } = new List<Project>();

        public static void Add(Project project)
        {
            project.Id = projects.Count;
            project.Visible = true;                
            projects.Add(project);
        }

        public static void RemoveById(int id)
        {
            projects[id].Visible = false;
        }

        public static List<Project> VisibleProjects()
        {
            var vProjects = new List<Project>();
            foreach (var p in projects)
            {
                if (p.Visible)
                    vProjects.Add(p);
            }
            return vProjects;
        }
    }
}
