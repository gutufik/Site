﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPDemo.Core
{
    public interface IProjectStorage
    {
        void Add(Project project);
        void RemoveById(int id);
    }

    public class ProjectStorage : IProjectStorage
    {
        public List<Project> Projects { get; private set; }

        public ProjectStorage()
        {
            Projects = DBEditor.GetProjects();
        }

        public void Add(Project project)
        {
            DBEditor.AddProject(project);
            Projects = DBEditor.GetProjects();
        }
        public void RemoveById(int id)
        {
            DBEditor.RemoveProject(id);
            Projects = DBEditor.GetProjects();
        }
    }
}
