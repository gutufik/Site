﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using ASPDemo.Core;

namespace ASPDemo.Core
{
    public static class DBEditor
    {
        
        public static List<Project> GetProjects()
        {
            List<Project> projects = new List<Project>();

            try
            {
                DBconnection.conn.Open();

                string sql = "SELECT * FROM OurSite.Project";
                MySqlCommand cmd = new MySqlCommand(sql, DBconnection.conn);
                MySqlDataReader res = cmd.ExecuteReader();

                while (res.Read())
                {
                    projects.Add(new Project { ID = Convert.ToInt32(res[0]), Name = res[1].ToString(), Description = res[2].ToString(), Link = res[3].ToString() });

                }
                res.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            DBconnection.conn.Close();
            return projects;
        }

        public static void RemoveProject(int id)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand($"DELETE from OurSite.Project where idProject = {id}", DBconnection.conn);
                DBconnection.conn.Open();
                cmd.ExecuteNonQuery();
                DBconnection.conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void AddProject(Project project)
        {
            try
            {
                MySqlCommand cmd = new MySqlCommand($"insert into OurSite.Project(Name, Description, Link) values('{project.Name}', '{project.Description}', '{project.Link}')", DBconnection.conn);
                DBconnection.conn.Open();
                cmd.ExecuteNonQuery();
                DBconnection.conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
