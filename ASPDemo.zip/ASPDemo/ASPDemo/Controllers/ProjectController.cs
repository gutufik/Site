﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ASPDemo.Core;

namespace ASPDemo.Controllers
{
    public class ProjectController : Controller
    {
        public IProjectStorage projects;

        public IActionResult Index(IProjectStorage _projects)
        {
            projects = _projects;
            return View((projects as ProjectStorage).Projects);
        }
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Project project)
        {
            projects.Add(project);
            return RedirectToAction("Index");
        }
        public IActionResult Remove(int id)
        {
            projects.RemoveById(id);
            return RedirectToAction("Index");
        }
    }
}
