﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JsonExam
{
    public class Project
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Link { get; set; }
        public string Description { get; set; }
        public bool Visible { get; set; }

        public  override string ToString()
        {
            return $"{Id} {Name} {Link} {Description} {Visible}";
        }
    }
    
}