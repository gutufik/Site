﻿using System;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Linq;

namespace JsonExam
{
    class MainClass
    {
        public static List<Project> projects = new List<Project>();

        public static void Main(string[] args)
        {
            var file = "/Users/201913/Projects/JsonExam/JsonExam/projects.json";
            var p = new Project
                    {
                        Id = 3,
                        Name = "asd",
                        Link = "zxc",
                        Description = "xyz",
                        Visible = true
                    };
            //Add(p, file);
            Remove(p, file);
            projects = Read(file);
            foreach (var pp in projects)
            {
                Console.WriteLine(pp.ToString());
            }

        }

        public static void Add(Project project, string file)
        {
            using (StreamWriter sw = new StreamWriter(file, true, System.Text.Encoding.Default))
            {
                sw.WriteLine(JsonConvert.SerializeObject(project));
            }
        }

        public static List<Project> Read(string file)
        {
            List<Project> projectss = new List<Project>();
            using (StreamReader sr = new StreamReader(file, System.Text.Encoding.Default))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    projectss.Add(JsonConvert.DeserializeObject<Project>(line));
                }
            }
            return projectss;
        }

        public static void Remove(Project project, string file)
        {
            var projects = Read(file);
            projects.Remove(projects.Where(p => project.Id == p.Id).FirstOrDefault());
            using (StreamWriter sw = new StreamWriter(file, false, System.Text.Encoding.Default))
            {
                foreach(var p in projects)
                    sw.WriteLine(JsonConvert.SerializeObject(p));
            }
        }
    }
}
